import { HighlightCardDirective } from './highlight-card.directive';

describe('HighlightCardDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightCardDirective();
    expect(directive).toBeTruthy();
  });
});
