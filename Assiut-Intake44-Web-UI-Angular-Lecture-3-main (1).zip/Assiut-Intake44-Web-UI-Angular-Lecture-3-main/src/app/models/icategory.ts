export interface Icategory {
    id:number;
    name:string;
}
